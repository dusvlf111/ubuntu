.. include:: common.txt

****************************
  pygame/examples/chimp.py
****************************

.. literalinclude:: ../../../examples/chimp.py
   :language: python
