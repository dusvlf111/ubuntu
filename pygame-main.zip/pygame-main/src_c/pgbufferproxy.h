#ifndef PG_BUFPROXY_INTERNAL_H
#define PG_BUFPROXY_INTERNAL_H

#include "include/pygame_bufferproxy.h"
#define PYGAMEAPI_BUFPROXY_NUMSLOTS 4

#endif /* ~PG_BUFPROXY_INTERNAL_H */
